Attribute VB_Name = "mod03_Regras_Alternancia"
' =========================================================
' MODULO 03 - REGRAS DE CELULAS E ALTERNANCIA
' Altere aqui quando precisar mudar a distribuicao entre
' tombadores/moegas ou o peso da alternancia.
' =========================================================

Public Sub AdicionarEnderecoRepetido(ByRef seq As Collection, ByVal ws As Worksheet, ByVal enderecoValor As String, Optional ByVal vezes As Long = 1)
    Dim n As Long

    If Trim$(ws.Range(enderecoValor).Value) = "" Then Exit Sub

    For n = 1 To vezes
        seq.Add enderecoValor
    Next n
End Sub

Public Sub AdicionarMoegaSeModo(ByRef seq As Collection, ByVal ws As Worksheet, ByVal enderecoValor As String, ByVal enderecoModo As String, ByVal modoDesejado As String, Optional ByVal vezes As Long = 1)
    Dim modoAtual As String

    If Trim$(ws.Range(enderecoValor).Value) = "" Then Exit Sub

    modoAtual = NormalizarModoDescarga(CStr(ws.Range(enderecoModo).Value), "VAGAO")

    If modoAtual = modoDesejado Then
        AdicionarEnderecoRepetido seq, ws, enderecoValor, vezes
    End If
End Sub

Public Function ValorDaProximaCelula(ByVal ws As Worksheet, ByVal seq As Collection, ByRef indiceAtual As Long) As String
    If seq.Count = 0 Then
        ValorDaProximaCelula = ""
        Exit Function
    End If

    indiceAtual = indiceAtual + 1
    If indiceAtual > seq.Count Then indiceAtual = 1

    ValorDaProximaCelula = Trim$(ws.Range(CStr(seq(indiceAtual))).Value)
End Function

Public Function EscolherCelulaEstocagem(ByVal ws As Worksheet, _
                                        ByVal ladoTerminal As String, _
                                        ByVal tipoVeiculo As String, _
                                        ByRef idxTEGCaminhao As Long, _
                                        ByRef idxTEGVagao As Long, _
                                        ByRef idxTEAGCaminhao As Long, _
                                        ByRef idxTEAGVagao As Long) As String
    Dim seq As New Collection
    Dim caminhao As Boolean

    caminhao = EhCaminhao(tipoVeiculo)
    ladoTerminal = UCase$(Trim$(ladoTerminal))

    If ladoTerminal = "TEG" Then

        If caminhao Then
            ' TEG caminhoes:
            ' Mantem a alternancia antiga dos tombadores: A4 4 vezes / B4 1 vez.
            AdicionarEnderecoRepetido seq, ws, "A4", 4
            AdicionarEnderecoRepetido seq, ws, "B4", 1

            ' Moegas C/D entram para caminhao somente se o dropdown estiver como "Descarga Caminhao".
            ' Mantem o peso antigo das moegas: C4 2 vezes / D4 1 vez.
            AdicionarMoegaSeModo seq, ws, "C4", "C5", "CAMINHAO", 2
            AdicionarMoegaSeModo seq, ws, "D4", "D5", "CAMINHAO", 1

            EscolherCelulaEstocagem = ValorDaProximaCelula(ws, seq, idxTEGCaminhao)

        Else
            ' TEG vagoes:
            ' Moegas C/D so recebem vagao se o dropdown estiver como "Descarga Vagao".
            AdicionarMoegaSeModo seq, ws, "C4", "C5", "VAGAO", 2
            AdicionarMoegaSeModo seq, ws, "D4", "D5", "VAGAO", 1

            EscolherCelulaEstocagem = ValorDaProximaCelula(ws, seq, idxTEGVagao)
        End If

    ElseIf ladoTerminal = "TEAG" Then

        If caminhao Then
            ' TEAG caminhoes:
            ' E4 e apenas caminhao.
            ' F/G/H entram para caminhao somente se o dropdown estiver como "Descarga Caminhao".
            AdicionarEnderecoRepetido seq, ws, "E4", 1
            AdicionarMoegaSeModo seq, ws, "F4", "F5", "CAMINHAO", 1
            AdicionarMoegaSeModo seq, ws, "G4", "G5", "CAMINHAO", 1
            AdicionarMoegaSeModo seq, ws, "H4", "H5", "CAMINHAO", 1

            EscolherCelulaEstocagem = ValorDaProximaCelula(ws, seq, idxTEAGCaminhao)

        Else
            ' TEAG vagoes:
            ' F/G/H so recebem vagao se o dropdown estiver como "Descarga Vagao".
            AdicionarMoegaSeModo seq, ws, "F4", "F5", "VAGAO", 1
            AdicionarMoegaSeModo seq, ws, "G4", "G5", "VAGAO", 1
            AdicionarMoegaSeModo seq, ws, "H4", "H5", "VAGAO", 1

            EscolherCelulaEstocagem = ValorDaProximaCelula(ws, seq, idxTEAGVagao)
        End If

    End If
End Function
