Attribute VB_Name = "mod02_Atualizar_Celulas"
' =========================================================
' MODULO 02 - SITE DAS CELULAS / NOTEETEG
' Atualiza A4:H4 com as celulas disponiveis e grava em
' C5/D5/F5/G5/H5 se cada moega esta como caminhao ou vagao.
' =========================================================

Sub AtualizarCelulas()
    Dim botUpdate As WebDriver
    Dim ws As Worksheet

    On Error GoTo TrataErro

    Set ws = ThisWorkbook.Sheets("MACRO")
    Set botUpdate = New WebDriver

    botUpdate.Start "chrome"
    botUpdate.Get "https://noteeteg.vercel.app"
    botUpdate.Wait 10000

    botUpdate.FindElementById("email").SendKeys "cco@tegporto.com.br"
    botUpdate.Wait 500
    botUpdate.FindElementById("password").SendKeys "qwerty12"
    botUpdate.Wait 500
    botUpdate.FindElementByXPath("(//button[normalize-space()='Entrar'])[1]").Click

    If WaitForElementDriver(botUpdate, "xpath", "(//button[normalize-space()='Estocagem'])[1]", 35) Then
        botUpdate.Wait 300
        botUpdate.FindElementByXPath("(//button[normalize-space()='Estocagem'])[1]").Click
        botUpdate.Wait 1500
    Else
        RegistrarLog "ERRO", "AtualizarCelulas: botao Estocagem nao encontrado no site noteeteg."
        GoTo Finalizar
    End If

    ' =========================================================
    ' Linha 4 = celula/local de armazenagem vindo do noteeteg
    ' Linha 5 = modo da moega: CAMINHAO ou VAGAO
    '
    ' A4 = Tombador 06          | A5 = CAMINHAO fixo
    ' B4 = Tombador 07          | B5 = CAMINHAO fixo
    ' C4 = Moega 01             | C5 = Dropdown Descarga Caminhao/Vagao
    ' D4 = Moega 02             | D5 = Dropdown Descarga Caminhao/Vagao
    ' E4 = Tombador 05          | E5 = CAMINHAO fixo
    ' F4 = Moega 03             | F5 = Dropdown Descarga Caminhao/Vagao
    ' G4 = Moega 04             | G5 = Dropdown Descarga Caminhao/Vagao
    ' H4 = Moega 05             | H5 = Dropdown Descarga Caminhao/Vagao
    ' =========================================================

    ws.Range("A4").Value = LerValorInputPorIds(botUpdate, Array("teg-road"))
    ws.Range("B4").Value = LerValorInputPorIds(botUpdate, Array("teg-road-tombador"))
    ws.Range("C4").Value = LerValorInputPorIds(botUpdate, Array("teg-railway-moega-01"))
    ws.Range("D4").Value = LerValorInputPorIds(botUpdate, Array("teg-railway-moega-02"))

    ws.Range("E4").Value = LerValorInputPorIds(botUpdate, Array("teag-road"))
    ws.Range("F4").Value = LerValorInputPorIds(botUpdate, Array("teag-railway-moega-03", "teag-railway"))
    ws.Range("G4").Value = LerValorInputPorIds(botUpdate, Array("teag-railway-moega-04"))
    ws.Range("H4").Value = LerValorInputPorIds(botUpdate, Array("teag-railway-moega-05"))

    ' Tombadores sao sempre caminhao.
    ws.Range("A5").Value = "CAMINHAO"
    ws.Range("B5").Value = "CAMINHAO"
    ws.Range("E5").Value = "CAMINHAO"

    ' Dropdowns das moegas.
    ' IMPORTANTE:
    ' Caso o ID real do dropdown no noteeteg seja diferente, ajuste apenas os arrays abaixo.
    ' A funcao tenta localizar por id, parte do id, name e data-testid.
    ' Se nao encontrar o dropdown, assume VAGAO para manter a logica antiga e evitar mandar vagao para tombador.
    ws.Range("C5").Value = LerModoMoega(botUpdate, Array("teg-railway-moega-01-mode", "teg-railway-moega-01-tipo", "teg-railway-moega-01-descarga", "teg-railway-moega-01"), "VAGAO")
    ws.Range("D5").Value = LerModoMoega(botUpdate, Array("teg-railway-moega-02-mode", "teg-railway-moega-02-tipo", "teg-railway-moega-02-descarga", "teg-railway-moega-02"), "VAGAO")
    ws.Range("F5").Value = LerModoMoega(botUpdate, Array("teag-railway-moega-03-mode", "teag-railway-moega-03-tipo", "teag-railway-moega-03-descarga", "teag-railway-moega-03", "teag-railway"), "VAGAO")
    ws.Range("G5").Value = LerModoMoega(botUpdate, Array("teag-railway-moega-04-mode", "teag-railway-moega-04-tipo", "teag-railway-moega-04-descarga", "teag-railway-moega-04"), "VAGAO")
    ws.Range("H5").Value = LerModoMoega(botUpdate, Array("teag-railway-moega-05-mode", "teag-railway-moega-05-tipo", "teag-railway-moega-05-descarga", "teag-railway-moega-05"), "VAGAO")

    ws.Range("A5:H5").Font.Color = RGB(120, 120, 120)

    RegistrarLog "INFO", "Celulas atualizadas: A4:H4 / modos C5,D5,F5,G5,H5 - " & Now
    Debug.Print "Celulas atualizadas as " & Now

Finalizar:
    On Error Resume Next
    If Not botUpdate Is Nothing Then botUpdate.Quit
    Set botUpdate = Nothing
    On Error GoTo 0
    Exit Sub

TrataErro:
    RegistrarLog "ERRO", "Erro em AtualizarCelulas - " & Err.Number & " - " & Err.Description
    Resume Finalizar
End Sub
